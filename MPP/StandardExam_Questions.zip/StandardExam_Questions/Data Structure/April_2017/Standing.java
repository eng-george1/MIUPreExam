package prob1;

public enum Standing {
	FRESHMAN, SOPHOMORE, JUNIOR, SENIOR;
}
