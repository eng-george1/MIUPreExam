package prob1;


public class ArrayQueueImpl {

	private int[] arr = new int[10];
	private int front = -1;
	private int rear = 0;
	
	
	public int peek() {
		return -1;
		//implement
	}
	
	public void enqueue(int obj){
		//implement
	}
	
	public int dequeue() {
		return -1;
		//implement
	}
	
	public boolean isEmpty(){	
		//implement
		return false;
	}
	
	public int size(){	
		//implement
		return 0;
	}
	
}
