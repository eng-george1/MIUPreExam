package prob2;

/** A list of bicycle brands */
public enum Brand {
   SCHWINN, TREK, SURLY, BIANCHI;
}
