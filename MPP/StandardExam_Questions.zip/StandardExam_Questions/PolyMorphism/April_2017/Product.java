package prob2;

public interface Product {
   //implement
}
