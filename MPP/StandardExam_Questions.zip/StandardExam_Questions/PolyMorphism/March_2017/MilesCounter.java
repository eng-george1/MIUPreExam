package prob2;

import java.util.List;

public class MilesCounter {
	public static List/*<implement>*/ convertArray(Object[] vehicleArray) {
		/* implement */
		return null;
	}
	
	
	public static int computeTotalMiles(List/*<implement>*/ vehicleList) {
		/*implement */
		return -1;
	}
}
