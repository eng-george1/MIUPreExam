package prob2;

public abstract class Vehicle {

}
