package Polymorphism_March_2018;

public interface BoardingTime {

	public double computeBoardingTime();
}
