package Polymorphism_March_2018;

public enum Status {

	 GOLD, SILVER, PLATINUM;
}
